/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package test.com.game.view;

import com.game.view.PlayerPanel;
import org.junit.Assert;
import org.junit.Test;

public class PlayerPanelTest {
    @Test
    public void init() {
        PlayerPanel playerPanel = new PlayerPanel();
        Assert.assertTrue(playerPanel.getSnake().isAlive());
        Assert.assertNotEquals(playerPanel.getFood().getScore(), playerPanel.getBonus().getScore());
    }

    @Test
    public void go() {
        PlayerPanel playerPanel = new PlayerPanel();
        playerPanel.go();
    }
}
