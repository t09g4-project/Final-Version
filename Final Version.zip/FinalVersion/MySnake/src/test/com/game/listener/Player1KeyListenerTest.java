/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package test.com.game.listener;

import com.game.common.Direction;
import com.game.listener.Player1KeyListener;
import com.game.model.Snake;
import org.junit.Assert;
import org.junit.Test;

import javax.swing.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Player1KeyListenerTest {
    @Test
    public void pressUp() {
        Snake snake = new Snake(1,1 , "a.png");
        JPanel panel = new JPanel();
        KeyListener keyListener = new Player1KeyListener(snake);
        panel.addKeyListener(keyListener);
        Assert.assertEquals(snake.getDirection(), Direction.RIGHT);
        KeyEvent e = new KeyEvent(panel,1, 1, InputEvent.BUTTON1_DOWN_MASK, KeyEvent.VK_UP);
        keyListener.keyPressed(e);
        Assert.assertEquals(snake.getDirection(), Direction.UP);
    }
}
