/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package test.com.game.model;

import com.game.common.Configure;
import com.game.common.Direction;
import com.game.model.Food;
import com.game.model.Bonus;
import com.game.model.Poison;
import com.game.model.Snake;
import org.junit.Assert;
import org.junit.Test;


public class ModelTest {

    // Snake eat food shoud grow two body
    @Test
    public void eatFood() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        Food food = new Food();
        snake.eatElement(food);
        Assert.assertEquals(2, snake.getBodies().size());
    }

    @Test
    public void eatPoison() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        Poison poison = new Poison();
        snake.eatElement(poison);
        Assert.assertEquals(1, snake.getBodies().size());
    }

    @Test
    public void nextY() {
        Snake snake = new Snake(0, 1, Configure.ImageRootPath);
        snake.setDirection(Direction.DOWN);
        Assert.assertEquals(2, snake.nextY());
    }
    
    @Test
    public void eatBonus() {
    	Snake snake = new Snake(0 , 0, Configure.ImageRootPath);
    	Bonus bonus = new Bonus();
    	snake.eatElement(bonus);
    	Assert.assertEquals(3, snake.getBodies().size());
    }

    @Test
    public void moveNormally() {
        Snake snake = new Snake(1, 1, Configure.ImageRootPath);
        snake.setDirection(Direction.DOWN);
        snake.eatElement(null);
        Assert.assertEquals(1, snake.getBodies().size());
        Assert.assertEquals(2, snake.getBodies().getFirst().getY());
    }
}
