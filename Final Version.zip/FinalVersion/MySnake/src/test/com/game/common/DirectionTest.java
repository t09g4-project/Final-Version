/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package test.com.game.common;

import com.game.common.Direction;
import org.junit.Assert;
import org.junit.Test;

public class DirectionTest {
    @Test
    public void directionSizeShouldBeFour() {
        Assert.assertEquals(4, Direction.values().length);
    }
}
