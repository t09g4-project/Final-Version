/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package com.game;

import com.game.model.GameFrame;

/**
 * This class is the model method to run the program
 */
public class Main {

    public static void main(String[] args) {
        new GameFrame();
    }
}
