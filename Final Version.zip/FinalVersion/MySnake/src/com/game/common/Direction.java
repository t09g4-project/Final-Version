/**
* @author T-09 G04��Tianqi Tao Qingyang Lu Darren Banh Jinyang Ju Shude Li
* @version Final Version
* @since 2019-04-10
*/
package com.game.common;

/**
 * This class contains the predefined directions to move
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT
    // for directions to move
}
