/**
* @author T-09 G04
* @version Final Version
* @since 2019-04-10
*/
package com.game.common;

/**
 * This class contains the predefined directions to move
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT
    // for directions to move
}
