package test.com.game.common;

import com.game.common.Configure;
import com.game.common.Direction;
import org.junit.Assert;
import org.junit.Test;

public class ConfigureTest {
    @Test
    public void foodConfig() {
        Assert.assertEquals("MySnake/src/resources/1score.png", Configure.Food.image);
    }
}
