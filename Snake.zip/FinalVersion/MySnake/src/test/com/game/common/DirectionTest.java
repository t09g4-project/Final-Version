package test.com.game.common;

import com.game.common.Direction;
import org.junit.Assert;
import org.junit.Test;

public class DirectionTest {
    @Test
    public void directionSizeShouldBeFour() {
        Assert.assertEquals(4, Direction.values().length);
    }
}
